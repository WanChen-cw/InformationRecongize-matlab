for j=12:1:20
for i=1:3
    BSC(2^j,0.02*i);
end
end
